module FStar.Mul
open Prims
let (*) = Prims.op_Multiply
